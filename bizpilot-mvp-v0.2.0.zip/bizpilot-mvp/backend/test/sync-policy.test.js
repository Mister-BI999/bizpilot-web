import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateSaleStock, validateOperationEnvelope } from '../src/sync-policy.js';

test('sale stock policy accepts sale when tracked stock is sufficient', () => {
  const result = evaluateSaleStock([{ productId: 'p1', quantity: 2 }], new Map([['p1', { stock: 5, trackStock: true }]]));
  assert.equal(result.ok, true);
  assert.deepEqual(result.shortages, []);
});
test('sale stock policy rejects overselling and reports server availability', () => {
  const result = evaluateSaleStock([{ productId: 'p1', quantity: 3 }], new Map([['p1', { stock: 1, trackStock: true }]]));
  assert.equal(result.ok, false);
  assert.deepEqual(result.shortages, [{ productId: 'p1', reason: 'insufficient_stock', requested: 3, available: 1 }]);
});
test('sale stock policy does not block service or untracked stock', () => {
  const result = evaluateSaleStock([{ productId: 'svc', quantity: 50 }], new Map([['svc', { stock: 0, trackStock: false }]]));
  assert.equal(result.ok, true);
});
test('missing product is a conflict, never silently ignored', () => {
  const result = evaluateSaleStock([{ productId: 'missing', quantity: 1 }], new Map());
  assert.equal(result.ok, false);
  assert.equal(result.shortages[0].reason, 'product_missing');
});
test('sync envelope requires an id, device id, type and object payload', () => {
  assert.equal(validateOperationEnvelope({ id: 'op1', type: 'sale.create', deviceId: 'phone-1', payload: {} }), true);
  assert.equal(validateOperationEnvelope({ id: 'op1', type: 'sale.create', deviceId: 'phone-1', payload: [] }), false);
  assert.equal(validateOperationEnvelope({ type: 'sale.create', deviceId: 'phone-1', payload: {} }), false);
});
