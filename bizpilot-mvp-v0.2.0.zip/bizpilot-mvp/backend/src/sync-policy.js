export function evaluateSaleStock(lines, stockByProduct) {
  const requested = new Map();
  for (const line of lines) requested.set(line.productId, (requested.get(line.productId) ?? 0) + Number(line.quantity));
  const shortages = [];
  for (const [productId, quantity] of requested) {
    const product = stockByProduct.get(productId);
    if (!product) shortages.push({ productId, reason: 'product_missing', requested: quantity, available: 0 });
    else if (product.trackStock && Number(product.stock) < quantity) {
      shortages.push({ productId, reason: 'insufficient_stock', requested: quantity, available: Number(product.stock) });
    }
  }
  return { ok: shortages.length === 0, shortages };
}

export function validateOperationEnvelope(op) {
  return Boolean(op && typeof op.id === 'string' && op.id.length <= 80 &&
    typeof op.type === 'string' && typeof op.deviceId === 'string' &&
    op.payload && typeof op.payload === 'object' && !Array.isArray(op.payload));
}
