export const ROLES = ['owner', 'admin', 'cashier', 'stock_manager', 'accountant', 'viewer'];
const permissions = {
  owner: ['*'],
  admin: ['members:read','members:invite','products:read','products:write','sales:read','sales:write','expenses:read','expenses:write','reports:read','conflicts:read','conflicts:resolve'],
  cashier: ['products:read','sales:read','sales:write'],
  stock_manager: ['products:read','products:write','sales:read','conflicts:read','conflicts:resolve'],
  accountant: ['products:read','sales:read','expenses:read','expenses:write','reports:read','conflicts:read'],
  viewer: ['products:read','sales:read','expenses:read','reports:read']
};
export function hasPermission(role, permission) {
  const list = permissions[role] ?? [];
  return list.includes('*') || list.includes(permission);
}
