import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import pg from 'pg';
import { z } from 'zod';
import { hasPermission, ROLES } from './roles.js';
import { evaluateSaleStock, validateOperationEnvelope } from './sync-policy.js';

const { Pool } = pg;
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10, idleTimeoutMillis: 30_000 });
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET || '';
if (JWT_SECRET.length < 32) throw new Error('JWT_SECRET doit contenir au moins 32 caractères. Configurez backend/.env.');
app.disable('x-powered-by');
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: (process.env.CORS_ORIGIN || 'http://localhost:5173').split(',').map(s => s.trim()), credentials: false }));
app.use(express.json({ limit: '256kb' }));

class HttpError extends Error { constructor(status, message, details) { super(message); this.status = status; this.details = details; } }
const uuid = z.string().uuid();
const registerSchema = z.object({ email: z.string().email().max(254), password: z.string().min(10).max(128), fullName: z.string().trim().min(2).max(120), organizationName: z.string().trim().min(2).max(160) });
const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1).max(128), organizationId: uuid.optional() });
const productSchema = z.object({ id: uuid, name: z.string().trim().min(1).max(180), kind: z.enum(['product','service']), price: z.number().int().nonnegative().max(9_000_000_000), cost: z.number().int().nonnegative().max(9_000_000_000).default(0), stock: z.number().nonnegative().max(1_000_000_000).default(0), trackStock: z.boolean().default(true) });
const operationSchema = z.object({ id: uuid, deviceId: z.string().min(1).max(120), type: z.enum(['product.upsert','sale.create','expense.create','stock.adjust']), payload: z.record(z.any()) });
const inviteSchema = z.object({ email: z.string().email().max(254), role: z.enum(['admin','cashier','stock_manager','accountant','viewer']) });
const acceptInviteSchema = z.object({ token: z.string().min(20).max(200), fullName: z.string().trim().min(2).max(120), password: z.string().min(10).max(128) });

function asyncRoute(fn) { return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next); }
function issueToken(user, organizationId, role) {
  return jwt.sign({ sub: user.id, org: organizationId, role }, JWT_SECRET, { expiresIn: '12h', issuer: 'bizpilot-api', audience: 'bizpilot-client' });
}
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return next(new HttpError(401, 'Authentification requise.'));
  try {
    const token = jwt.verify(header.slice(7), JWT_SECRET, { issuer: 'bizpilot-api', audience: 'bizpilot-client' });
    req.auth = { userId: token.sub, organizationId: token.org, role: token.role };
    next();
  } catch { next(new HttpError(401, 'Jeton invalide ou expiré.')); }
}
function requirePermission(permission) {
  return (req, res, next) => hasPermission(req.auth?.role, permission) ? next() : next(new HttpError(403, 'Permission insuffisante.'));
}
async function inTransaction(fn) {
  const client = await pool.connect();
  try { await client.query('BEGIN'); const result = await fn(client); await client.query('COMMIT'); return result; }
  catch (error) { await client.query('ROLLBACK'); throw error; }
  finally { client.release(); }
}

app.get('/health', asyncRoute(async (_req, res) => {
  await pool.query('SELECT 1'); res.json({ status: 'ok', service: 'bizpilot-api', database: 'ok' });
}));

app.post('/v1/auth/register', asyncRoute(async (req, res) => {
  const data = registerSchema.parse(req.body);
  const email = data.email.toLowerCase();
  const passwordHash = await bcrypt.hash(data.password, 12);
  const created = await inTransaction(async client => {
    const userResult = await client.query('INSERT INTO users(email,password_hash,full_name) VALUES($1,$2,$3) RETURNING id,email,full_name', [email, passwordHash, data.fullName]);
    const user = userResult.rows[0];
    const orgResult = await client.query('INSERT INTO organizations(name,created_by) VALUES($1,$2) RETURNING id,name,currency', [data.organizationName, user.id]);
    const org = orgResult.rows[0];
    await client.query("INSERT INTO memberships(organization_id,user_id,role) VALUES($1,$2,'owner')", [org.id, user.id]);
    return { user, org };
  }).catch(error => { if (error.code === '23505') throw new HttpError(409, 'Cette adresse e-mail est déjà utilisée.'); throw error; });
  res.status(201).json({ token: issueToken(created.user, created.org.id, 'owner'), user: created.user, organization: created.org, role: 'owner' });
}));

app.post('/v1/auth/login', asyncRoute(async (req, res) => {
  const data = loginSchema.parse(req.body);
  const userResult = await pool.query('SELECT id,email,full_name,password_hash,disabled_at FROM users WHERE email=$1', [data.email.toLowerCase()]);
  const user = userResult.rows[0];
  if (!user || user.disabled_at || !(await bcrypt.compare(data.password, user.password_hash))) throw new HttpError(401, 'Identifiants incorrects.');
  const memberships = await pool.query('SELECT o.id,o.name,o.currency,m.role FROM memberships m JOIN organizations o ON o.id=m.organization_id WHERE m.user_id=$1 ORDER BY o.created_at', [user.id]);
  if (!memberships.rowCount) throw new HttpError(403, 'Aucune entreprise associée à ce compte.');
  const membership = data.organizationId ? memberships.rows.find(m => m.id === data.organizationId) : memberships.rows[0];
  if (!membership) throw new HttpError(403, 'Vous n’êtes pas membre de cette entreprise.');
  res.json({ token: issueToken(user, membership.id, membership.role), user: { id: user.id, email: user.email, fullName: user.full_name }, organization: { id: membership.id, name: membership.name, currency: membership.currency }, role: membership.role, organizations: memberships.rows.map(m => ({ id: m.id, name: m.name, currency: m.currency, role: m.role })) });
}));

app.get('/v1/auth/me', auth, asyncRoute(async (req, res) => {
  const result = await pool.query('SELECT u.id,u.email,u.full_name,o.id AS organization_id,o.name AS organization_name,o.currency,m.role FROM users u JOIN memberships m ON m.user_id=u.id JOIN organizations o ON o.id=m.organization_id WHERE u.id=$1 AND o.id=$2 AND u.disabled_at IS NULL', [req.auth.userId, req.auth.organizationId]);
  if (!result.rowCount) throw new HttpError(401, 'Compte ou appartenance désactivé.');
  const r = result.rows[0]; res.json({ user: { id: r.id, email: r.email, fullName: r.full_name }, organization: { id: r.organization_id, name: r.organization_name, currency: r.currency }, role: r.role });
}));

app.post('/v1/organizations/:organizationId/invitations', auth, requirePermission('members:invite'), asyncRoute(async (req, res) => {
  if (req.params.organizationId !== req.auth.organizationId) throw new HttpError(403, 'Entreprise non autorisée.');
  const data = inviteSchema.parse(req.body);
  const rawToken = crypto.randomBytes(32).toString('base64url');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const result = await pool.query('INSERT INTO invitations(organization_id,email,role,token_hash,expires_at,created_by) VALUES($1,$2,$3,$4,now()+interval \'72 hours\',$5) RETURNING id,email,role,expires_at', [req.auth.organizationId, data.email.toLowerCase(), data.role, tokenHash, req.auth.userId]);
  // Token is returned once for manual sharing; integrate a mail/SMS provider before production.
  res.status(201).json({ invitation: result.rows[0], token: rawToken, delivery: 'manual' });
}));

app.post('/v1/auth/accept-invitation', asyncRoute(async (req, res) => {
  const data = acceptInviteSchema.parse(req.body);
  const tokenHash = crypto.createHash('sha256').update(data.token).digest('hex');
  const result = await inTransaction(async client => {
    const inviteResult = await client.query('SELECT * FROM invitations WHERE token_hash=$1 AND accepted_at IS NULL AND expires_at>now() FOR UPDATE', [tokenHash]);
    const invitation = inviteResult.rows[0];
    if (!invitation) throw new HttpError(400, 'Invitation invalide, expirée ou déjà utilisée.');
    const existing = await client.query('SELECT id,email,full_name,password_hash FROM users WHERE email=$1 FOR UPDATE', [invitation.email]);
    let user = existing.rows[0];
    if (user) {
      if (!(await bcrypt.compare(data.password, user.password_hash))) throw new HttpError(409, 'Un compte existe déjà avec cet e-mail. Connectez-vous avec son mot de passe.');
    } else {
      const hash = await bcrypt.hash(data.password, 12);
      user = (await client.query('INSERT INTO users(email,password_hash,full_name) VALUES($1,$2,$3) RETURNING id,email,full_name', [invitation.email, hash, data.fullName])).rows[0];
    }
    await client.query('INSERT INTO memberships(organization_id,user_id,role) VALUES($1,$2,$3) ON CONFLICT(organization_id,user_id) DO UPDATE SET role=EXCLUDED.role', [invitation.organization_id, user.id, invitation.role]);
    await client.query('UPDATE invitations SET accepted_at=now() WHERE id=$1', [invitation.id]);
    const org = (await client.query('SELECT id,name,currency FROM organizations WHERE id=$1', [invitation.organization_id])).rows[0];
    return { user, org, role: invitation.role };
  });
  res.status(201).json({ token: issueToken(result.user, result.org.id, result.role), user: { id: result.user.id, email: result.user.email, fullName: result.user.full_name }, organization: result.org, role: result.role });
}));

app.get('/v1/organizations/:organizationId/members', auth, requirePermission('members:read'), asyncRoute(async (req, res) => {
  if (req.params.organizationId !== req.auth.organizationId) throw new HttpError(403, 'Entreprise non autorisée.');
  const result = await pool.query('SELECT u.id,u.email,u.full_name,m.role,m.created_at FROM memberships m JOIN users u ON u.id=m.user_id WHERE m.organization_id=$1 ORDER BY m.created_at', [req.auth.organizationId]);
  res.json({ members: result.rows.map(r => ({ id: r.id, email: r.email, fullName: r.full_name, role: r.role, joinedAt: r.created_at })) });
}));

app.get('/v1/products', auth, requirePermission('products:read'), asyncRoute(async (req, res) => {
  const result = await pool.query('SELECT id,name,kind,price,cost,stock,track_stock,version,updated_at FROM products WHERE organization_id=$1 ORDER BY name', [req.auth.organizationId]);
  res.json({ products: result.rows.map(r => ({ id:r.id,name:r.name,kind:r.kind,price:Number(r.price),cost:Number(r.cost),stock:Number(r.stock),trackStock:r.track_stock,version:Number(r.version),updatedAt:r.updated_at })) });
}));

app.get('/v1/sync/conflicts', auth, requirePermission('conflicts:read'), asyncRoute(async (req, res) => {
  const result = await pool.query("SELECT id,operation_id,device_id,conflict_type,payload,server_state,status,created_at FROM sync_conflicts WHERE organization_id=$1 AND status='open' ORDER BY created_at", [req.auth.organizationId]);
  res.json({ conflicts: result.rows });
}));

app.post('/v1/sync/conflicts/:conflictId/resolve', auth, requirePermission('conflicts:resolve'), asyncRoute(async (req, res) => {
  const schema = z.object({ action: z.enum(['discard']) });
  const { action } = schema.parse(req.body);
  const result = await pool.query("UPDATE sync_conflicts SET status='resolved',resolution=$3::jsonb,resolved_at=now() WHERE id=$1 AND organization_id=$2 AND status='open' RETURNING id,status,resolved_at", [req.params.conflictId, req.auth.organizationId, JSON.stringify({ action, resolvedBy: req.auth.userId })]);
  if (!result.rowCount) throw new HttpError(404, 'Conflit introuvable ou déjà traité.');
  res.json({ conflict: result.rows[0], note: 'La vente conflictuelle n’a pas été appliquée. Si nécessaire, corrigez le stock puis créez une nouvelle opération.' });
}));

async function applyOperation(client, authContext, op) {
  const orgId = authContext.organizationId;
  const userId = authContext.userId;
  if (op.type === 'product.upsert') {
    if (!hasPermission(authContext.role, 'products:write')) throw new HttpError(403, 'Permission products:write requise.');
    const p = productSchema.parse(op.payload);
    const existing = await client.query('SELECT version FROM products WHERE organization_id=$1 AND id=$2 FOR UPDATE', [orgId, p.id]);
    if (existing.rowCount) {
      // Never overwrite a newer concurrent edit with an older offline edit.
      if (op.payload.baseVersion !== undefined && Number(op.payload.baseVersion) !== Number(existing.rows[0].version)) {
        return { status: 'conflict', result: { code: 'product_version_conflict', productId: p.id, serverVersion: Number(existing.rows[0].version) } };
      }
      const updated = await client.query('UPDATE products SET name=$3,kind=$4,price=$5,cost=$6,track_stock=$7,version=version+1,updated_at=now() WHERE organization_id=$1 AND id=$2 RETURNING version', [orgId,p.id,p.name,p.kind,p.price,p.cost,p.trackStock]);
      return { status: 'applied', result: { productId: p.id, version: Number(updated.rows[0].version) } };
    }
    await client.query('INSERT INTO products(organization_id,id,name,kind,price,cost,stock,track_stock) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [orgId,p.id,p.name,p.kind,p.price,p.cost,p.stock,p.trackStock]);
    return { status: 'applied', result: { productId: p.id, version: 1 } };
  }
  if (op.type === 'sale.create') {
    if (!hasPermission(authContext.role, 'sales:write')) throw new HttpError(403, 'Permission sales:write requise.');
    const saleSchema = z.object({ id: uuid, createdAt: z.string().datetime(), lines: z.array(z.object({ itemId: uuid, name: z.string().min(1).max(180), quantity: z.number().positive().max(1_000_000), unitPrice: z.number().int().nonnegative(), unitCost: z.number().int().nonnegative() })).min(1).max(200), total: z.number().int().nonnegative(), costTotal: z.number().int().nonnegative(), paymentMethod: z.string().min(1).max(60), amountPaid: z.number().int().nonnegative(), note: z.string().max(1000).default('') });
    const sale = saleSchema.parse(op.payload);
    const aggregated = new Map();
    for (const line of sale.lines) {
      const previous = aggregated.get(line.itemId);
      if (previous) { previous.quantity += line.quantity; previous.unitPrice = line.unitPrice; previous.unitCost = line.unitCost; }
      else aggregated.set(line.itemId, { ...line, productId: line.itemId });
    }
    const lines = [...aggregated.values()].sort((a,b) => a.productId.localeCompare(b.productId));
    const productIds = lines.map(l => l.productId);
    const productsResult = await client.query('SELECT id,stock,track_stock,name FROM products WHERE organization_id=$1 AND id=ANY($2::uuid[]) ORDER BY id FOR UPDATE', [orgId, productIds]);
    const stockByProduct = new Map(productsResult.rows.map(p => [p.id, { stock: Number(p.stock), trackStock: p.track_stock, name: p.name }]));
    const decision = evaluateSaleStock(lines, stockByProduct);
    if (!decision.ok) {
      const response = { code: 'stock_conflict', saleId: sale.id, shortages: decision.shortages.map(s => ({ ...s, productName: stockByProduct.get(s.productId)?.name ?? null })) };
      await client.query('INSERT INTO sync_conflicts(organization_id,operation_id,device_id,conflict_type,payload,server_state) VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb) ON CONFLICT(organization_id,operation_id) DO NOTHING', [orgId,op.id,op.deviceId,'stock_conflict',JSON.stringify(op),JSON.stringify({ shortages: response.shortages })]);
      return { status: 'conflict', result: response };
    }
    const calculatedTotal = sale.lines.reduce((sum,l) => sum + l.quantity*l.unitPrice, 0);
    const calculatedCost = sale.lines.reduce((sum,l) => sum + l.quantity*l.unitCost, 0);
    if (Math.round(calculatedTotal) !== sale.total || Math.round(calculatedCost) !== sale.costTotal) throw new HttpError(422, 'Les totaux de vente ne correspondent pas aux lignes.');
    await client.query('INSERT INTO sales(organization_id,id,created_by,device_id,total,cost_total,payment_method,amount_paid,note,occurred_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)', [orgId,sale.id,userId,op.deviceId,sale.total,sale.costTotal,sale.paymentMethod,sale.amountPaid,sale.note,sale.createdAt]);
    for (const [index, line] of sale.lines.entries()) {
      await client.query('INSERT INTO sale_items(organization_id,sale_id,product_id,line_no,name_snapshot,quantity,unit_price,unit_cost) VALUES($1,$2,$3,$4,$5,$6,$7,$8)', [orgId,sale.id,line.itemId,index,line.name,line.quantity,line.unitPrice,line.unitCost]);
    }
    for (const line of lines) {
      const p = stockByProduct.get(line.productId);
      if (p?.trackStock) {
        await client.query('UPDATE products SET stock=stock-$3,version=version+1,updated_at=now() WHERE organization_id=$1 AND id=$2', [orgId,line.productId,line.quantity]);
        await client.query("INSERT INTO stock_movements(organization_id,product_id,movement_type,quantity_delta,source_id,device_id,created_by) VALUES($1,$2,'sale',$3,$4,$5,$6)", [orgId,line.productId,-line.quantity,sale.id,op.deviceId,userId]);
      }
    }
    return { status: 'applied', result: { saleId: sale.id, total: sale.total, stockUpdated: true } };
  }
  if (op.type === 'expense.create') {
    if (!hasPermission(authContext.role, 'expenses:write')) throw new HttpError(403, 'Permission expenses:write requise.');
    const e = z.object({ id: uuid, label: z.string().trim().min(1).max(180), amount: z.number().int().nonnegative(), createdAt: z.string().datetime() }).parse(op.payload);
    await client.query('INSERT INTO expenses(organization_id,id,created_by,label,amount,occurred_at) VALUES($1,$2,$3,$4,$5,$6)', [orgId,e.id,userId,e.label,e.amount,e.createdAt]);
    return { status: 'applied', result: { expenseId: e.id } };
  }
  if (op.type === 'stock.adjust') {
    if (!hasPermission(authContext.role, 'products:write')) throw new HttpError(403, 'Permission products:write requise.');
    const a = z.object({ productId: uuid, delta: z.number().finite().min(-1_000_000_000).max(1_000_000_000), reason: z.string().trim().min(2).max(250) }).parse(op.payload);
    const product = await client.query('SELECT stock,track_stock FROM products WHERE organization_id=$1 AND id=$2 FOR UPDATE', [orgId,a.productId]);
    if (!product.rowCount) throw new HttpError(404, 'Produit introuvable.');
    const nextStock = Number(product.rows[0].stock) + a.delta;
    if (nextStock < 0) return { status: 'conflict', result: { code: 'stock_adjustment_conflict', productId: a.productId, available: Number(product.rows[0].stock), delta: a.delta } };
    await client.query('UPDATE products SET stock=$3,version=version+1,updated_at=now() WHERE organization_id=$1 AND id=$2', [orgId,a.productId,nextStock]);
    await client.query("INSERT INTO stock_movements(organization_id,product_id,movement_type,quantity_delta,source_id,device_id,created_by) VALUES($1,$2,'adjustment',$3,$4,$5,$6)", [orgId,a.productId,a.delta,op.id,op.deviceId,userId]);
    return { status: 'applied', result: { productId: a.productId, stock: nextStock } };
  }
  throw new HttpError(422, 'Type d’opération non pris en charge.');
}

app.post('/v1/sync/batch', auth, asyncRoute(async (req, res) => {
  const batchSchema = z.object({ operations: z.array(z.any()).min(1).max(100) });
  const { operations } = batchSchema.parse(req.body);
  const results = [];
  for (const raw of operations) {
    if (!validateOperationEnvelope(raw)) { results.push({ id: raw?.id ?? null, status: 'rejected', error: 'Enveloppe d’opération invalide.' }); continue; }
    const parsed = operationSchema.safeParse(raw);
    if (!parsed.success) { results.push({ id: raw.id, status: 'rejected', error: 'Format d’opération invalide.' }); continue; }
    try {
      const result = await inTransaction(async client => {
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))', [req.auth.organizationId, raw.id]);
        const prior = await client.query('SELECT status,response FROM sync_operations WHERE organization_id=$1 AND operation_id=$2', [req.auth.organizationId,raw.id]);
        if (prior.rowCount) return { status: prior.rows[0].status, result: prior.rows[0].response, duplicate: true };
        const applied = await applyOperation(client, req.auth, parsed.data);
        if (applied.status === 'conflict') {
          await client.query('INSERT INTO sync_conflicts(organization_id,operation_id,device_id,conflict_type,payload,server_state) VALUES($1,$2,$3,$4,$5::jsonb,$6::jsonb) ON CONFLICT(organization_id,operation_id) DO NOTHING', [req.auth.organizationId,raw.id,raw.deviceId,applied.result?.code || 'sync_conflict',JSON.stringify(raw),JSON.stringify(applied.result || {})]);
        }
        await client.query('INSERT INTO sync_operations(organization_id,operation_id,device_id,operation_type,status,response) VALUES($1,$2,$3,$4,$5,$6::jsonb)', [req.auth.organizationId,raw.id,raw.deviceId,raw.type,applied.status,JSON.stringify(applied.result)]);
        return applied;
      });
      results.push({ id: raw.id, ...result });
    } catch (error) {
      if (error instanceof z.ZodError) results.push({ id: raw.id, status: 'rejected', error: 'Données de l’opération invalides.', details: error.issues.map(i => ({ path: i.path.join('.'), message: i.message })) });
      else if (error instanceof HttpError) results.push({ id: raw.id, status: 'rejected', error: error.message });
      else if (error.code === '23505') {
        // Duplicate entity IDs not caused by an operation retry are surfaced; never silently treated as success.
        results.push({ id: raw.id, status: 'conflict', error: 'Identifiant déjà utilisé par une autre opération.' });
      } else throw error;
    }
  }
  res.json({ results, serverTime: new Date().toISOString() });
}));

app.use((err, req, res, _next) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: 'Requête invalide.', details: err.issues.map(i => ({ path: i.path.join('.'), message: i.message })) });
  const status = err.status || 500;
  if (status >= 500) console.error('API error:', err.message);
  res.status(status).json({ error: status >= 500 ? 'Erreur interne du serveur.' : err.message, ...(err.details ? { details: err.details } : {}) });
});
const server = app.listen(PORT, () => console.log(`BizPilot API écoute sur http://localhost:${PORT}`));
async function shutdown() { server.close(); await pool.end(); process.exit(0); }
process.on('SIGTERM', shutdown); process.on('SIGINT', shutdown);
