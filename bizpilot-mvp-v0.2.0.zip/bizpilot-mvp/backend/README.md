# BizPilot Central API — v0.2.0

API REST Node.js/Express + PostgreSQL pour les organisations, utilisateurs, rôles, catalogue, ventes et synchronisation hors connexion.

## Démarrage local

Prérequis : Docker Compose, Node.js 20.19+ (ou version compatible) et npm.

1. Depuis la racine du projet :

   ```bash
   docker compose up -d postgres
   ```

2. Préparer la configuration API :

   ```bash
   cd backend
   cp .env.example .env
   ```

   Pour un usage partagé ou en production, remplacez `JWT_SECRET` par une valeur aléatoire d'au moins 32 caractères et changez le mot de passe PostgreSQL de développement. Ne publiez jamais le fichier `.env`.

3. Installer et migrer :

   ```bash
   npm install
   npm run migrate
   npm test
   npm run dev
   ```

4. Vérifier : `http://localhost:4000/health` doit renvoyer `{"status":"ok","service":"bizpilot-api","database":"ok"}`.

## Principales routes

- `POST /v1/auth/register` — créer un compte, une entreprise et son propriétaire.
- `POST /v1/auth/login` — connexion; accepte `organizationId` si le compte appartient à plusieurs entreprises.
- `GET /v1/auth/me` — identité, entreprise et rôle du jeton courant.
- `POST /v1/organizations/:organizationId/invitations` — inviter un membre (owner/admin). Le jeton est renvoyé pour partage manuel; aucun e-mail n'est envoyé.
- `POST /v1/auth/accept-invitation` — accepter une invitation et rejoindre l'entreprise.
- `GET /v1/organizations/:organizationId/members` — liste des membres.
- `GET /v1/products` — catalogue de l'entreprise courante.
- `POST /v1/sync/batch` — envoyer jusqu'à 100 opérations en attente.
- `GET /v1/sync/conflicts` — consulter les conflits ouverts.
- `POST /v1/sync/conflicts/:conflictId/resolve` avec `{ "action": "discard" }` — classer un conflit sans appliquer la vente.

Les routes protégées nécessitent `Authorization: Bearer <token>`. Le jeton est limité à une entreprise et expire après 12 heures.

## Format de synchronisation

Chaque opération possède un identifiant UUID stable, conservé lors des nouvelles tentatives. Le serveur enregistre le résultat avec la clé `(organization_id, operation_id)` et utilise un verrou transactionnel pour que deux requêtes concurrentes du même identifiant ne traitent pas l'opération deux fois.

```json
{
  "operations": [
    {
      "id": "UUID-DE-L-OPERATION",
      "deviceId": "UUID-STABLE-DE-L-APPAREIL",
      "type": "sale.create",
      "payload": {
        "id": "UUID-DE-LA-VENTE",
        "createdAt": "2026-10-29T17:00:00.000Z",
        "lines": [{"itemId":"UUID-DU-PRODUIT","name":"Riz 5 kg","quantity":2,"unitPrice":2500,"unitCost":2100}],
        "total": 5000,
        "costTotal": 4200,
        "paymentMethod": "Wave",
        "amountPaid": 5000,
        "note": ""
      }
    }
  ]
}
```

Types pris en charge :

- `product.upsert`: `payload` comprend `id`, `name`, `kind` (`product`/`service`), `price`, `cost`, `stock`, `trackStock`. Pour modifier le stock d'un produit déjà synchronisé, utilisez `stock.adjust` plutôt que de pousser un stock local complet.
- `sale.create`: format illustré ci-dessus. Les totaux sont recalculés et contrôlés côté serveur.
- `expense.create`: `payload` comprend `id`, `label`, `amount`, `createdAt`.
- `stock.adjust`: `payload` comprend `productId`, `delta` (positif ou négatif) et `reason`.

Chaque résultat a `status: applied`, `conflict` ou `rejected`. Une vente dont le stock central est insuffisant n'est pas créée; un conflit persistant est enregistré avec l'état du stock central. Après réapprovisionnement ou correction, l'utilisateur doit créer une nouvelle opération avec un nouvel identifiant. Le conflit peut être classé `discard`; cette action ne crée jamais la vente.

## Règles de sûreté de synchronisation

- Les ventes hors ligne sont des intentions locales, pas une garantie de stock central. Une vente hors ligne peut entrer en conflit si un autre appareil a vendu le dernier article.
- Le serveur verrouille les lignes de produits dans un ordre stable et contrôle le stock dans la même transaction que la vente et les mouvements de stock.
- Les nouvelles tentatives avec le même identifiant d'opération renvoient le résultat enregistré au lieu de refaire la vente.
- Toutes les requêtes de données sont limitées à l'entreprise présente dans le jeton; les identifiants d'une autre entreprise ne donnent pas accès à ses données.
- Les stocks existants ne sont pas remplacés lors d'une mise à jour de fiche produit; utiliser un mouvement `stock.adjust`.
- Les conflits sont conservés dans `sync_conflicts` pour audit et traitement.

## Client hors connexion

`../src/sync-client.ts` contient un client de synchronisation à brancher après l'écran de connexion. Il lit le journal IndexedDB, envoie les opérations en attente, marque les opérations appliquées et met les conflits à part. Il n'est pas encore branché automatiquement dans l'interface actuelle : aucune synchronisation silencieuse n'est prétendue active. Le code actuel du journal local historique doit également être adapté pour toujours inclure des UUID stables et générer `stock.adjust` pour les corrections de stock.

## Tests

`npm test` exécute les tests unitaires de la politique de stock et de l'enveloppe de synchronisation sans base de données. Pour valider les routes, migrations, transactions et concurrence de bout en bout, démarrer PostgreSQL et ajouter/exécuter la suite d'intégration dans un environnement de test isolé.

## Avant production

Ce dépôt est une base de développement, pas une certification de sécurité. Avant tout déploiement : HTTPS obligatoire, secrets gérés hors du dépôt, limitation de débit sur l'authentification, politique de récupération de compte, journal d'audit, sauvegardes PostgreSQL avec tests de restauration, rotation/révocation des jetons, monitoring, tests d'intégration et de concurrence, politique de confidentialité, et configuration d'un fournisseur e-mail/SMS pour les invitations. Ne pas exposer directement le port PostgreSQL à Internet.
