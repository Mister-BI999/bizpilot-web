# BizPilot MVP — v0.1.0

Première base exécutable de BizPilot : application web responsive installable (PWA), avec configuration préparée pour un emballage Android via Capacitor, catalogue produits/services, ventes, paiements déclarés, dépenses, indicateurs simples, stockage local IndexedDB et journal local des opérations en attente.

> **État honnête du livrable :** c'est un MVP local mono-appareil. Le stockage local des données est réel. Le cache de l'interface est préparé pour le mode hors connexion. Le serveur distant, la synchronisation multi-appareils, les comptes utilisateurs, les permissions, les paiements Mobile Money automatisés et le projet natif Android généré ne sont pas encore implémentés. Les opérations « en attente » ne sont pas transmises à un serveur dans cette version.

## Prérequis

- Node.js 20.19+ ou 22.12+ recommandé
- npm
- Un navigateur récent (Chrome, Edge ou Firefox récent)

## Lancer en développement

Dans un terminal, depuis le dossier `bizpilot-mvp` :

```bash
npm install
npm run dev
```

Ouvrir l'URL locale affichée par Vite, généralement `http://localhost:5173`.

## Vérifier le code

```bash
npm test
npm run build
npm run preview
```

Les tests utilisent le runner natif de Node.js et couvrent les calculs, validations de catalogue et règles de stock. Les tests ne simulent pas encore un navigateur complet.

## Préparer la version Android

Après avoir installé les dépendances et généré une version web :

```bash
npm run build
npm run android:add
npm run android:sync
npm run android:open
```

La génération Android nécessite Android Studio et le SDK Android sur votre ordinateur. La configuration Capacitor est incluse, mais le dossier natif Android est créé sur votre machine par `android:add`.

## Tester le hors connexion

1. Ouvrir l'application dans Chrome via l'URL de développement.
2. Ajouter un produit avec prix et stock, puis enregistrer une vente.
3. Recharger la page : les données doivent rester présentes dans IndexedDB.
4. Dans les outils de développement du navigateur, activer le mode réseau « Offline » puis continuer à consulter et enregistrer les données déjà chargées.
5. Pour vérifier l'installation PWA et le cache de l'interface, construire puis servir l'application (`npm run build` puis `npm run preview`), ouvrir une première fois l'URL de prévisualisation en ligne et recharger en mode hors connexion.

Note : le serveur de développement Vite lui-même ne fonctionne pas sans réseau/serveur local. Pour un test réaliste du cache PWA, utiliser la version construite et préchargée.

## Données et confidentialité

Les données sont enregistrées dans la base IndexedDB du navigateur et ne quittent pas automatiquement l'appareil. Elles peuvent être supprimées si les données du navigateur sont effacées ou si l'appareil est perdu. Utiliser « Exporter mes données JSON » pour créer une copie manuelle. Ne pas y saisir de données réelles sensibles avant la mise en place des comptes, sauvegardes et protections serveur.

## Limites fonctionnelles connues à traiter avant un pilote commercial

- Pas de backend, de connexion/gestion des utilisateurs ou d'isolation entre entreprises.
- Pas de synchronisation réelle, de résolution des conflits, ni de sauvegarde distante.
- Le journal local des opérations sert de base technique et reste en attente tant qu'un backend n'existe pas.
- Pas de ventilation détaillée des paiements mixtes, de retours/remboursements, de taxes, de factures légales ou de clôture de caisse.
- Les ventes sont destinées à une utilisation locale mono-appareil dans cette version. Ne pas utiliser simultanément plusieurs appareils comme s'ils partageaient un stock central.
- Le calcul de marge est indicatif et dépend de la saisie correcte du coût des articles.

## Étape technique suivante

Ajouter un backend authentifié (API + base PostgreSQL), les organisations et rôles, puis un protocole de synchronisation idempotent avec gestion des conflits de stock et tests automatisés avant tout déploiement chez des commerçants.

## Backend central (v0.2.0)

Le dossier `backend/` contient l'API REST Express, les migrations PostgreSQL, l'authentification JWT, les entreprises/membres/rôles et le protocole de synchronisation idempotent. Voir [`backend/README.md`](backend/README.md) pour les commandes, les routes et le format d'opération. À la racine, lancer PostgreSQL avec `docker compose up -d postgres`, puis suivre le guide du backend.

Le module `src/sync-client.ts` est le client de synchronisation à intégrer à l'interface de connexion. Il n'est pas encore déclenché automatiquement depuis l'interface. Le serveur central et les règles de conflits sont du code source fourni à tester en environnement local avant tout pilote réel.
