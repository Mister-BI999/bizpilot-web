import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Activity, Boxes, ChartNoAxesCombined, CircleDollarSign, CloudOff, Plus, ReceiptText, RefreshCw, ShoppingCart, Wifi, WifiOff } from 'lucide-react';
import { db } from './db';
import { calculateCostTotal, calculateSaleTotal, makeId, money, validateCatalogItem, validateSale, type CatalogItem, type Expense, type OutboxOperation, type PaymentMethod, type Sale, type SaleLine } from './domain';
import './style.css';

type Tab = 'Accueil' | 'Ventes' | 'Catalogue' | 'Dépenses' | 'Rapports';
const tabs: { name: Tab; icon: React.ReactNode }[] = [
  { name: 'Accueil', icon: <ChartNoAxesCombined size={18} /> },
  { name: 'Ventes', icon: <ShoppingCart size={18} /> },
  { name: 'Catalogue', icon: <Boxes size={18} /> },
  { name: 'Dépenses', icon: <ReceiptText size={18} /> },
  { name: 'Rapports', icon: <Activity size={18} /> },
];
const paymentMethods: PaymentMethod[] = ['Espèces', 'Wave', 'Orange Money', 'MTN Mobile Money', 'Mixte', 'Autre'];
function operation(entity: OutboxOperation['entity'], entityId: string): OutboxOperation {
  return { id: makeId(), entity, entityId, operation: 'create', createdAt: new Date().toISOString(), status: 'pending' };
}
function App() {
  const [tab, setTab] = useState<Tab>('Accueil');
  const [catalog, setCatalog] = useState<CatalogItem[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [outbox, setOutbox] = useState<OutboxOperation[]>([]);
  const [online, setOnline] = useState(navigator.onLine);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState('');
  const [showProductForm, setShowProductForm] = useState(false);
  const [showSaleForm, setShowSaleForm] = useState(false);
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [productName, setProductName] = useState('');
  const [productKind, setProductKind] = useState<'Produit' | 'Service'>('Produit');
  const [productPrice, setProductPrice] = useState('');
  const [productCost, setProductCost] = useState('');
  const [productStock, setProductStock] = useState('0');
  const [trackStock, setTrackStock] = useState(true);
  const [saleItemId, setSaleItemId] = useState('');
  const [saleQty, setSaleQty] = useState('1');
  const [saleLines, setSaleLines] = useState<SaleLine[]>([]);
  const [payment, setPayment] = useState<PaymentMethod>('Espèces');
  const [amountPaid, setAmountPaid] = useState('');
  const [saleNote, setSaleNote] = useState('');
  const [expenseLabel, setExpenseLabel] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');

  async function reload() {
    const [items, saleRows, expenseRows, pending] = await Promise.all([
      db.all<CatalogItem>('catalog'), db.all<Sale>('sales'), db.all<Expense>('expenses'), db.all<OutboxOperation>('outbox'),
    ]);
    setCatalog(items.sort((a, b) => a.name.localeCompare(b.name, 'fr')));
    setSales(saleRows.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    setExpenses(expenseRows.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
    setOutbox(pending.filter((item) => item.status === 'pending'));
  }
  useEffect(() => {
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline); window.addEventListener('offline', onOffline);
    reload().catch((error) => setNotice(error instanceof Error ? error.message : 'Erreur de chargement.')).finally(() => setLoading(false));
    if ('serviceWorker' in navigator && import.meta.env.PROD) navigator.serviceWorker.register('/sw.js').catch(() => undefined);
    return () => { window.removeEventListener('online', onOnline); window.removeEventListener('offline', onOffline); };
  }, []);
  const totalSales = useMemo(() => sales.reduce((sum, sale) => sum + sale.total, 0), [sales]);
  const totalCosts = useMemo(() => sales.reduce((sum, sale) => sum + sale.costTotal, 0), [sales]);
  const totalExpenses = useMemo(() => expenses.reduce((sum, expense) => sum + expense.amount, 0), [expenses]);
  const totalPaid = useMemo(() => sales.reduce((sum, sale) => sum + sale.amountPaid, 0), [sales]);
  const margin = totalSales - totalCosts - totalExpenses;
  const today = new Date().toLocaleDateString('fr-FR');
  const salesToday = sales.filter((sale) => new Date(sale.createdAt).toLocaleDateString('fr-FR') === today).reduce((sum, sale) => sum + sale.total, 0);
  const outOfStock = catalog.filter((item) => item.trackStock && item.stock <= 0).length;

  async function addProduct(event: React.FormEvent) {
    event.preventDefault();
    const candidate = { name: productName, kind: productKind, price: Number(productPrice), cost: Number(productCost || 0), stock: productKind === 'Service' ? 0 : Number(productStock || 0), trackStock: productKind === 'Produit' && trackStock };
    const errors = validateCatalogItem(candidate);
    if (errors.length) { setNotice(errors.join(' ')); return; }
    const item: CatalogItem = { ...candidate, id: makeId(), createdAt: new Date().toISOString() };
    try { await db.saveCatalogItem(item, operation('product', item.id)); await reload(); setProductName(''); setProductPrice(''); setProductCost(''); setProductStock('0'); setShowProductForm(false); setNotice('Article enregistré sur cet appareil.'); }
    catch (error) { setNotice(error instanceof Error ? error.message : 'Enregistrement impossible.'); }
  }
  function addLine() {
    const item = catalog.find((entry) => entry.id === saleItemId);
    const quantity = Number(saleQty);
    if (!item || !Number.isFinite(quantity) || quantity <= 0) { setNotice('Choisissez un article et une quantité valide.'); return; }
    const already = saleLines.filter((line) => line.itemId === item.id).reduce((sum, line) => sum + line.quantity, 0);
    if (item.trackStock && already + quantity > item.stock) { setNotice(`Stock insuffisant : ${item.name} (${item.stock} disponible(s)).`); return; }
    setSaleLines((prev) => { const existing = prev.find((line) => line.itemId === item.id); return existing ? prev.map((line) => line.itemId === item.id ? { ...line, quantity: line.quantity + quantity } : line) : [...prev, { itemId: item.id, name: item.name, quantity, unitPrice: item.price, unitCost: item.cost }]; }); setSaleItemId(''); setSaleQty('1'); setNotice('');
  }
  async function saveSale(event: React.FormEvent) {
    event.preventDefault();
    const errors = validateSale(saleLines, catalog);
    if (errors.length) { setNotice(errors.join(' ')); return; }
    const total = calculateSaleTotal(saleLines);
    const costTotal = calculateCostTotal(saleLines);
    const paid = amountPaid.trim() === '' ? total : Number(amountPaid);
    if (!Number.isFinite(paid) || paid < 0 || paid > total) { setNotice('Le montant payé doit être compris entre 0 et le total de la vente.'); return; }
    const sale: Sale = { id: makeId(), createdAt: new Date().toISOString(), lines: saleLines, total, costTotal, paymentMethod: payment, amountPaid: paid, note: saleNote.trim(), syncStatus: 'pending' };
    try {
      // Persist the sale, outbox operation and stock changes in one local IndexedDB transaction.
      const updatedItems = saleLines.flatMap((line) => {
        const item = catalog.find((entry) => entry.id === line.itemId);
        return item?.trackStock ? [{ ...item, stock: item.stock - line.quantity }] : [];
      });
      await db.commitSale(sale, updatedItems, operation('sale', sale.id)); await reload(); setSaleLines([]); setAmountPaid(''); setSaleNote(''); setShowSaleForm(false); setTab('Ventes'); setNotice(`Vente enregistrée localement : ${money(total)}.`);
    } catch (error) { setNotice(error instanceof Error ? error.message : 'Vente non enregistrée.'); }
  }
  async function saveExpense(event: React.FormEvent) {
    event.preventDefault();
    const amount = Number(expenseAmount);
    if (!expenseLabel.trim() || !Number.isFinite(amount) || amount <= 0) { setNotice('Indiquez un libellé et un montant supérieur à zéro.'); return; }
    const expense: Expense = { id: makeId(), label: expenseLabel.trim(), amount, createdAt: new Date().toISOString(), syncStatus: 'pending' };
    try { await db.saveExpense(expense, operation('expense', expense.id)); await reload(); setExpenseLabel(''); setExpenseAmount(''); setShowExpenseForm(false); setNotice('Dépense enregistrée sur cet appareil.'); }
    catch (error) { setNotice(error instanceof Error ? error.message : 'Dépense non enregistrée.'); }
  }
  async function exportData() {
    const data = { exportedAt: new Date().toISOString(), catalog, sales, expenses, pendingOperations: outbox };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `bizpilot-export-${new Date().toISOString().slice(0, 10)}.json`; anchor.click(); URL.revokeObjectURL(url);
  }
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">B</div><div><strong>BizPilot</strong><small>Votre activité, maîtrisée.</small></div></div>
      <div className="workspace"><span className="workspace-dot" /> Mon entreprise <span className="chevron">⌄</span></div>
      <nav>{tabs.map((item) => <button key={item.name} className={`nav-item ${tab === item.name ? 'active' : ''}`} onClick={() => setTab(item.name)}>{item.icon}<span>{item.name}</span></button>)}</nav>
      <div className="sidebar-bottom"><div className="offline-card"><div className="offline-icon"><CloudOff size={18} /></div><div><strong>Mode hors ligne</strong><small>Vos données restent sur cet appareil.</small></div></div><button className="export-link" onClick={exportData}>Exporter mes données JSON</button><small className="version">MVP local · v0.1.0</small></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div><div className="eyebrow">ESPACE DE GESTION</div><h1>{tab === 'Accueil' ? 'Vue d’ensemble' : tab}</h1></div><div className={`connection ${online ? 'connected' : 'disconnected'}`}>{online ? <Wifi size={16} /> : <WifiOff size={16} />}<span>{online ? 'Connecté' : 'Hors connexion'}</span><span className="pending-pill">{outbox.length} en attente</span></div></header>
      {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Fermer">×</button></div>}
      {loading ? <div className="empty-state">Ouverture du registre local…</div> : <>
      {tab === 'Accueil' && <>
        <section className="welcome"><div><div className="welcome-label">VOTRE ACTIVITÉ EN UN COUP D’ŒIL</div><h2>Bonjour ! 👋</h2><p>Voici où en est votre activité. Vos opérations sont sauvegardées sur cet appareil, même sans Internet.</p></div><div className="welcome-illustration"><CircleDollarSign size={58} strokeWidth={1.2} /></div></section>
        <section className="stats-grid">
          <Stat label="Ventes du jour" value={money(salesToday)} icon={<ShoppingCart />} tone="green" note={`${sales.filter((sale) => new Date(sale.createdAt).toLocaleDateString('fr-FR') === today).length} vente(s)`} />
          <Stat label="Ventes cumulées" value={money(totalSales)} icon={<CircleDollarSign />} tone="blue" note={`${sales.length} transaction(s)`} />
          <Stat label="Marge estimée" value={money(margin)} icon={<ChartNoAxesCombined />} tone="orange" note="Avant impôts et autres charges" />
          <Stat label="À synchroniser" value={String(outbox.length)} icon={<RefreshCw />} tone="purple" note={online ? 'Serveur non configuré dans ce MVP' : 'En attente de connexion'} />
        </section>
        <section className="content-grid"><div className="panel"><div className="panel-heading"><div><h3>Activité récente</h3><p>Les dernières ventes enregistrées</p></div><button className="text-button" onClick={() => setTab('Ventes')}>Tout voir →</button></div>{sales.length === 0 ? <Empty icon={<ShoppingCart />} title="Pas encore de vente" text="Enregistrez votre première vente pour commencer à suivre votre activité." action="Nouvelle vente" onClick={() => setShowSaleForm(true)} /> : <div className="activity-list">{sales.slice(0, 5).map((sale) => <div className="activity-row" key={sale.id}><div className="activity-icon"><ShoppingCart size={17} /></div><div className="activity-description"><strong>Vente · {sale.lines.length} ligne(s)</strong><small>{new Date(sale.createdAt).toLocaleString('fr-FR')} · {sale.paymentMethod}</small></div><div className="activity-amount">{money(sale.total)}<small>{sale.syncStatus === 'synced' ? 'Synchronisée' : 'Sur cet appareil'}</small></div></div>)}</div>}</div>
          <div className="panel quick-panel"><div className="panel-heading"><div><h3>Actions rapides</h3><p>Gérez votre quotidien</p></div></div><button className="quick-action" onClick={() => { setShowSaleForm(true); setTab('Ventes'); }}><span className="quick-icon green-bg"><Plus size={18} /></span><span><strong>Enregistrer une vente</strong><small>Vente au comptoir ou service</small></span><span className="quick-arrow">→</span></button><button className="quick-action" onClick={() => { setShowProductForm(true); setTab('Catalogue'); }}><span className="quick-icon blue-bg"><Boxes size={18} /></span><span><strong>Ajouter au catalogue</strong><small>Produit ou prestation</small></span><span className="quick-arrow">→</span></button><button className="quick-action" onClick={() => { setShowExpenseForm(true); setTab('Dépenses'); }}><span className="quick-icon orange-bg"><ReceiptText size={18} /></span><span><strong>Enregistrer une dépense</strong><small>Transport, loyer, achat…</small></span><span className="quick-arrow">→</span></button><div className="stock-alert"><span className="alert-dot" /><span><strong>{outOfStock} article(s) en rupture</strong><small>Vérifiez votre catalogue</small></span><button onClick={() => setTab('Catalogue')}>Voir</button></div></div></section>
      </>}
      {tab === 'Catalogue' && <section className="panel page-panel"><div className="panel-heading"><div><h3>Catalogue</h3><p>Produits et services, avec suivi du stock en option.</p></div><button className="primary-button" onClick={() => setShowProductForm(!showProductForm)}><Plus size={17} /> Ajouter</button></div>{showProductForm && <form className="form-card" onSubmit={addProduct}><h4>Nouvel article</h4><div className="form-grid"><Field label="Nom" value={productName} onChange={setProductName} required placeholder="Ex. Sac de riz / Consultation"/><label className="field"><span>Type</span><select value={productKind} onChange={(e) => { const kind = e.target.value as 'Produit' | 'Service'; setProductKind(kind); if (kind === 'Service') setTrackStock(false); }}><option>Produit</option><option>Service</option></select></label><Field label="Prix de vente (F CFA)" value={productPrice} onChange={setProductPrice} required type="number" min="0"/><Field label="Coût unitaire (F CFA)" value={productCost} onChange={setProductCost} type="number" min="0"/><Field label="Stock initial" value={productStock} onChange={setProductStock} type="number" min="0" disabled={productKind === 'Service'}/></div>{productKind === 'Produit' && <label className="check-field"><input type="checkbox" checked={trackStock} onChange={(e) => setTrackStock(e.target.checked)}/> Suivre les quantités en stock</label>}<div className="form-actions"><button type="button" className="secondary-button" onClick={() => setShowProductForm(false)}>Annuler</button><button className="primary-button" type="submit">Enregistrer l’article</button></div></form>}{catalog.length === 0 ? <Empty icon={<Boxes />} title="Votre catalogue est vide" text="Ajoutez un produit ou un service pour pouvoir l’utiliser dans une vente." action="Ajouter un article" onClick={() => setShowProductForm(true)} /> : <div className="table-wrap"><table><thead><tr><th>Article</th><th>Type</th><th>Prix de vente</th><th>Coût</th><th>Stock</th></tr></thead><tbody>{catalog.map((item) => <tr key={item.id}><td><strong>{item.name}</strong><small className="subcell">Ajouté le {new Date(item.createdAt).toLocaleDateString('fr-FR')}</small></td><td><span className="type-tag">{item.kind}</span></td><td>{money(item.price)}</td><td>{money(item.cost)}</td><td>{item.trackStock ? <span className={item.stock <= 0 ? 'stock-zero' : 'stock-ok'}>{item.stock}</span> : <span className="muted">Non suivi</span>}</td></tr>)}</tbody></table></div>}</section>}
      {tab === 'Ventes' && <section className="panel page-panel"><div className="panel-heading"><div><h3>Ventes</h3><p>Enregistrez les ventes et les paiements reçus.</p></div><button className="primary-button" onClick={() => setShowSaleForm(!showSaleForm)}><Plus size={17}/> Nouvelle vente</button></div>{showSaleForm && <form className="form-card" onSubmit={saveSale}><h4>Nouvelle vente</h4>{catalog.length === 0 ? <p className="form-hint">Ajoutez d’abord au moins un article dans le catalogue.</p> : <><div className="add-line"><label className="field grow"><span>Produit ou service</span><select value={saleItemId} onChange={(e) => setSaleItemId(e.target.value)}><option value="">Choisir un article…</option>{catalog.map((item) => <option key={item.id} value={item.id}>{item.name} — {money(item.price)}{item.trackStock ? ` (stock : ${item.stock})` : ''}</option>)}</select></label><Field label="Qté" value={saleQty} onChange={setSaleQty} type="number" min="0.01"/><button type="button" className="secondary-button add-line-button" onClick={addLine}>Ajouter</button></div>{saleLines.length > 0 && <div className="sale-lines">{saleLines.map((line, index) => <div className="sale-line" key={`${line.itemId}-${index}`}><span>{line.name} × {line.quantity}</span><strong>{money(line.quantity * line.unitPrice)}</strong><button type="button" aria-label="Retirer" onClick={() => setSaleLines((prev) => prev.filter((_, i) => i !== index))}>×</button></div>)}<div className="sale-total"><span>Total à payer</span><strong>{money(calculateSaleTotal(saleLines))}</strong></div></div>}<div className="form-grid"><label className="field"><span>Mode de paiement</span><select value={payment} onChange={(e) => setPayment(e.target.value as PaymentMethod)}>{paymentMethods.map((method) => <option key={method}>{method}</option>)}</select></label><Field label="Montant reçu (vide = total)" value={amountPaid} onChange={setAmountPaid} type="number" min="0"/><Field label="Note (facultatif)" value={saleNote} onChange={setSaleNote} placeholder="Nom client, référence…"/></div><p className="form-hint">Les paiements mixtes peuvent être notés, mais leur ventilation par moyen de paiement sera ajoutée dans une prochaine version.</p><div className="form-actions"><button type="button" className="secondary-button" onClick={() => { setShowSaleForm(false); setSaleLines([]); }}>Annuler</button><button className="primary-button" type="submit">Enregistrer la vente</button></div></>}</form>}{sales.length === 0 ? <Empty icon={<ShoppingCart />} title="Aucune vente enregistrée" text="Les ventes seront conservées sur cet appareil même si Internet est coupé." action="Créer une vente" onClick={() => setShowSaleForm(true)} /> : <div className="table-wrap"><table><thead><tr><th>Date</th><th>Articles</th><th>Paiement</th><th>Total</th><th>État</th></tr></thead><tbody>{sales.map((sale) => <tr key={sale.id}><td>{new Date(sale.createdAt).toLocaleString('fr-FR')}</td><td>{sale.lines.map((line) => `${line.name} × ${line.quantity}`).join(', ')}{sale.note && <small className="subcell">{sale.note}</small>}</td><td>{sale.paymentMethod}<small className="subcell">Reçu : {money(sale.amountPaid)}</small></td><td><strong>{money(sale.total)}</strong></td><td><span className="pending-tag">En local</span></td></tr>)}</tbody></table></div>}</section>}
      {tab === 'Dépenses' && <section className="panel page-panel"><div className="panel-heading"><div><h3>Dépenses</h3><p>Gardez une trace des charges de votre activité.</p></div><button className="primary-button" onClick={() => setShowExpenseForm(!showExpenseForm)}><Plus size={17}/> Ajouter une dépense</button></div>{showExpenseForm && <form className="form-card" onSubmit={saveExpense}><h4>Nouvelle dépense</h4><div className="form-grid"><Field label="Libellé" value={expenseLabel} onChange={setExpenseLabel} required placeholder="Ex. Transport, loyer, électricité"/><Field label="Montant (F CFA)" value={expenseAmount} onChange={setExpenseAmount} type="number" min="1" required/></div><div className="form-actions"><button type="button" className="secondary-button" onClick={() => setShowExpenseForm(false)}>Annuler</button><button className="primary-button" type="submit">Enregistrer</button></div></form>}{expenses.length === 0 ? <Empty icon={<ReceiptText />} title="Aucune dépense enregistrée" text="Ajoutez les charges de l’entreprise pour obtenir une marge estimée plus pertinente." action="Ajouter une dépense" onClick={() => setShowExpenseForm(true)} /> : <div className="table-wrap"><table><thead><tr><th>Date</th><th>Libellé</th><th>Montant</th><th>État</th></tr></thead><tbody>{expenses.map((expense) => <tr key={expense.id}><td>{new Date(expense.createdAt).toLocaleString('fr-FR')}</td><td>{expense.label}</td><td><strong>{money(expense.amount)}</strong></td><td><span className="pending-tag">En local</span></td></tr>)}</tbody></table></div>}</section>}
      {tab === 'Rapports' && <><section className="stats-grid report-stats"><Stat label="Chiffre d’affaires" value={money(totalSales)} icon={<CircleDollarSign />} tone="green" note="Toutes les ventes enregistrées"/><Stat label="Coût des articles vendus" value={money(totalCosts)} icon={<Boxes />} tone="blue" note="Estimé selon les coûts saisis"/><Stat label="Dépenses" value={money(totalExpenses)} icon={<ReceiptText />} tone="orange" note="Charges saisies manuellement"/><Stat label="Marge estimée" value={money(margin)} icon={<ChartNoAxesCombined />} tone="purple" note="CA − coût vendu − dépenses"/></section><section className="panel page-panel"><div className="panel-heading"><div><h3>Résumé de gestion</h3><p>Vue calculée à partir des données enregistrées sur cet appareil.</p></div><button className="secondary-button" onClick={exportData}>Exporter JSON</button></div><div className="report-list"><div><span>Nombre de ventes</span><strong>{sales.length}</strong></div><div><span>Montant encaissé déclaré</span><strong>{money(totalPaid)}</strong></div><div><span>Créances estimées (total − encaissé)</span><strong>{money(Math.max(0, totalSales - totalPaid))}</strong></div><div><span>Articles au catalogue</span><strong>{catalog.length}</strong></div><div><span>Articles en rupture</span><strong>{outOfStock}</strong></div><div><span>Opérations en attente de synchronisation</span><strong>{outbox.length}</strong></div></div><p className="disclaimer">Ces chiffres sont des indicateurs de gestion, pas une comptabilité certifiée. Les retours, taxes, remboursements et rapprochements de caisse ne sont pas encore inclus.</p></section></>}
      </>}
      <footer className="footer"><span>BizPilot · MVP de développement</span><span><span className="footer-dot" /> Données stockées localement</span></footer>
    </main>
  </div>;
}
function Stat({ label, value, icon, tone, note }: { label: string; value: string; icon: React.ReactNode; tone: string; note: string }) { return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>; }
function Field({ label, value, onChange, required, type = 'text', placeholder, min, disabled }: { label: string; value: string; onChange: (value: string) => void; required?: boolean; type?: string; placeholder?: string; min?: string; disabled?: boolean }) { return <label className="field"><span>{label}</span><input value={value} onChange={(e) => onChange(e.target.value)} required={required} type={type} placeholder={placeholder} min={min} disabled={disabled}/></label>; }
function Empty({ icon, title, text, action, onClick }: { icon: React.ReactNode; title: string; text: string; action: string; onClick: () => void }) { return <div className="empty-state"><div className="empty-icon">{icon}</div><h4>{title}</h4><p>{text}</p><button className="secondary-button" onClick={onClick}>{action}</button></div>; }

createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
