export const money = (amount) => new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(amount) + ' F CFA';
export const makeId = () => typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
export function calculateSaleTotal(lines) {
  return lines.reduce((sum, line) => sum + line.quantity * line.unitPrice, 0);
}
export function calculateCostTotal(lines) {
  return lines.reduce((sum, line) => sum + line.quantity * line.unitCost, 0);
}
export function validateCatalogItem(item) {
  const errors = [];
  if (!item.name.trim()) errors.push('Le nom est obligatoire.');
  if (!Number.isFinite(item.price) || item.price < 0) errors.push('Le prix de vente doit être positif ou nul.');
  if (!Number.isFinite(item.cost) || item.cost < 0) errors.push('Le coût doit être positif ou nul.');
  if (!Number.isFinite(item.stock) || item.stock < 0) errors.push('Le stock doit être positif ou nul.');
  return errors;
}
export function validateSale(lines, catalog) {
  const errors = [];
  if (!lines.length) errors.push('Ajoutez au moins un article à la vente.');
  for (const line of lines) {
    if (!Number.isFinite(line.quantity) || line.quantity <= 0) errors.push(`Quantité invalide pour ${line.name}.`);
    const item = catalog.find((entry) => entry.id === line.itemId);
    if (!item) errors.push(`${line.name} n’existe plus dans le catalogue.`);
    else if (item.trackStock && line.quantity > item.stock) errors.push(`Stock insuffisant pour ${item.name} (disponible : ${item.stock}).`);
  }
  return errors;
}
