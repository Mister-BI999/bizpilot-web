import type { CatalogItem, SaleLine } from './domain';
export declare const money: (amount: number) => string;
export declare const makeId: () => string;
export declare function calculateSaleTotal(lines: Pick<SaleLine, 'quantity' | 'unitPrice'>[]): number;
export declare function calculateCostTotal(lines: Pick<SaleLine, 'quantity' | 'unitCost'>[]): number;
export declare function validateCatalogItem(item: Omit<CatalogItem, 'id' | 'createdAt'>): string[];
export declare function validateSale(lines: SaleLine[], catalog: CatalogItem[]): string[];
