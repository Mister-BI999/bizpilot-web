import type { CatalogItem, Sale, Expense, OutboxOperation } from './domain';

const DB_NAME = 'bizpilot-local-v1';
const DB_VERSION = 1;
type StoreName = 'catalog' | 'sales' | 'expenses' | 'outbox';
let dbPromise: Promise<IDBDatabase> | undefined;

function openDb(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') return Promise.reject(new Error('IndexedDB n’est pas disponible dans ce navigateur.'));
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('catalog')) db.createObjectStore('catalog', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('sales')) db.createObjectStore('sales', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('expenses')) db.createObjectStore('expenses', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('outbox')) db.createObjectStore('outbox', { keyPath: 'id' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error('Impossible d’ouvrir la base locale.'));
    });
  }
  return dbPromise;
}
function transaction<T>(store: StoreName, mode: IDBTransactionMode, action: (objectStore: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then((db) => new Promise<T>((resolve, reject) => {
    const tx = db.transaction(store, mode);
    const request = action(tx.objectStore(store));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Erreur de stockage local.'));
    tx.onabort = () => reject(tx.error ?? new Error('Transaction locale annulée.'));
  }));
}
export const db = {
  all<T>(store: StoreName): Promise<T[]> { return transaction(store, 'readonly', (s) => s.getAll()) as Promise<T[]>; },
  put<T extends { id: string }>(store: StoreName, value: T): Promise<IDBValidKey> { return transaction(store, 'readwrite', (s) => s.put(value)); },
  remove(store: StoreName, id: string): Promise<undefined> { return transaction(store, 'readwrite', (s) => s.delete(id)) as Promise<undefined>; },
  async saveCatalogItem(item: CatalogItem, operation: OutboxOperation) { await this.put('catalog', item); await this.put('outbox', operation); },
  async saveSale(sale: Sale, operation: OutboxOperation) { await this.put('sales', sale); await this.put('outbox', operation); },
  async commitSale(sale: Sale, updatedItems: CatalogItem[], operation: OutboxOperation) {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(['catalog', 'sales', 'outbox'], 'readwrite');
      const catalogStore = tx.objectStore('catalog');
      for (const item of updatedItems) catalogStore.put(item);
      tx.objectStore('sales').put(sale);
      tx.objectStore('outbox').put(operation);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Impossible d’enregistrer la vente.'));
      tx.onabort = () => reject(tx.error ?? new Error('Enregistrement de vente annulé.'));
    });
  },
  async saveExpense(expense: Expense, operation: OutboxOperation) { await this.put('expenses', expense); await this.put('outbox', operation); },
};
