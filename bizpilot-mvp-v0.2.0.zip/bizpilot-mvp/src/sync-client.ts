import type { CatalogItem, Expense, OutboxOperation, Sale } from './domain';
import { db } from './db';

type SyncResult = { id: string; status: 'applied' | 'conflict' | 'rejected'; result?: unknown; error?: string; duplicate?: boolean };
export type SyncSummary = { applied: number; conflicts: number; rejected: number; skipped: number; results: SyncResult[] };

/**
 * Pushes local outbox operations to BizPilot API. Call only after login and pass the
 * bearer token, stable device ID and organization API URL. The local sale remains
 * available even if the network request fails.
 */
export async function syncPendingOperations(token: string, deviceId: string, apiBaseUrl = 'http://localhost:4000'): Promise<SyncSummary> {
  if (!navigator.onLine) throw new Error('Connexion indisponible : les opérations restent sur cet appareil.');
  if (!token || !deviceId) throw new Error('Jeton de connexion et identifiant de l’appareil requis.');

  const [outbox, catalog, sales, expenses] = await Promise.all([
    db.all<OutboxOperation>('outbox'), db.all<CatalogItem>('catalog'), db.all<Sale>('sales'), db.all<Expense>('expenses'),
  ]);
  const pending = outbox.filter(op => op.status === 'pending');
  if (!pending.length) return { applied: 0, conflicts: 0, rejected: 0, skipped: outbox.length, results: [] };
  const productById = new Map(catalog.map(item => [item.id, item]));
  const saleById = new Map(sales.map(item => [item.id, item]));
  const expenseById = new Map(expenses.map(item => [item.id, item]));
  const operations = pending.map(op => {
    let type: string;
    let payload: Record<string, unknown>;
    if (op.entity === 'product') {
      const item = productById.get(op.entityId);
      if (!item) return null;
      type = 'product.upsert';
      payload = { ...item, kind: item.kind === 'Produit' ? 'product' : 'service', trackStock: item.trackStock };
    } else if (op.entity === 'sale') {
      const sale = saleById.get(op.entityId);
      if (!sale) return null;
      type = 'sale.create';
      payload = sale as unknown as Record<string, unknown>;
    } else {
      const expense = expenseById.get(op.entityId);
      if (!expense) return null;
      type = 'expense.create';
      payload = expense as unknown as Record<string, unknown>;
    }
    return { id: op.id, deviceId, type, payload };
  });
  const missing = operations.filter(op => op === null).length;
  const batch = operations.filter((op): op is NonNullable<typeof op> => op !== null);
  if (!batch.length) return { applied: 0, conflicts: 0, rejected: missing, skipped: 0, results: [] };

  const response = await fetch(`${apiBaseUrl.replace(/\/$/, '')}/v1/sync/batch`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ operations: batch }),
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({})) as { error?: string };
    throw new Error(body.error || `Échec de synchronisation (HTTP ${response.status}). Les données locales sont conservées.`);
  }
  const body = await response.json() as { results: SyncResult[] };
  const outboxById = new Map(outbox.map(op => [op.id, op]));
  for (const result of body.results) {
    const op = outboxById.get(result.id);
    if (!op) continue;
    if (result.status === 'applied') {
      await db.put('outbox', { ...op, status: 'synced', syncError: undefined });
      if (op.entity === 'sale') {
        const sale = saleById.get(op.entityId);
        if (sale) await db.put('sales', { ...sale, syncStatus: 'synced' });
      }
    } else {
      await db.put('outbox', { ...op, status: result.status === 'conflict' ? 'conflict' : 'pending', syncError: result.error || (result.status === 'conflict' ? JSON.stringify(result.result) : 'Opération rejetée') });
    }
  }
  return {
    applied: body.results.filter(r => r.status === 'applied').length,
    conflicts: body.results.filter(r => r.status === 'conflict').length,
    rejected: body.results.filter(r => r.status === 'rejected').length + missing,
    skipped: outbox.filter(op => op.status !== 'pending').length,
    results: body.results,
  };
}
