import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateSaleTotal, calculateCostTotal, validateCatalogItem, validateSale } from '../src/domain-core.mjs';

test('calculates sale total from quantity and unit price', () => {
  assert.equal(calculateSaleTotal([{ quantity: 2, unitPrice: 1500 }, { quantity: 3, unitPrice: 500 }]), 4500);
});
test('calculates cost total separately from sale total', () => {
  assert.equal(calculateCostTotal([{ quantity: 2, unitCost: 900 }, { quantity: 3, unitCost: 200 }]), 2400);
});
test('rejects a blank catalog name and negative price', () => {
  const errors = validateCatalogItem({ name: ' ', kind: 'Produit', price: -5, cost: 0, stock: 0, trackStock: true });
  assert.ok(errors.includes('Le nom est obligatoire.'));
  assert.ok(errors.includes('Le prix de vente doit être positif ou nul.'));
});
test('rejects a sale when tracked stock is insufficient', () => {
  const catalog = [{ id: 'p1', name: 'Riz', kind: 'Produit', price: 1000, cost: 800, stock: 2, trackStock: true, createdAt: '2026-01-01' }];
  const errors = validateSale([{ itemId: 'p1', name: 'Riz', quantity: 3, unitPrice: 1000, unitCost: 800 }], catalog);
  assert.deepEqual(errors, ['Stock insuffisant pour Riz (disponible : 2).']);
});
test('allows service sales when inventory is not tracked', () => {
  const catalog = [{ id: 's1', name: 'Réparation', kind: 'Service', price: 5000, cost: 1000, stock: 0, trackStock: false, createdAt: '2026-01-01' }];
  assert.deepEqual(validateSale([{ itemId: 's1', name: 'Réparation', quantity: 2, unitPrice: 5000, unitCost: 1000 }], catalog), []);
});
