import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.bizpilot.app',
  appName: 'BizPilot',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: { allowMixedContent: false },
};
export default config;
