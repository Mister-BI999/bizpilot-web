export type PaymentMethod = 'Espèces' | 'Wave' | 'Orange Money' | 'MTN Mobile Money' | 'Mixte' | 'Autre';
export type ProductKind = 'Produit' | 'Service';
export interface CatalogItem {
  id: string;
  name: string;
  kind: ProductKind;
  price: number;
  cost: number;
  stock: number;
  trackStock: boolean;
  createdAt: string;
}
export interface SaleLine { itemId: string; name: string; quantity: number; unitPrice: number; unitCost: number; }
export interface Sale {
  id: string;
  createdAt: string;
  lines: SaleLine[];
  total: number;
  costTotal: number;
  paymentMethod: PaymentMethod;
  amountPaid: number;
  note: string;
  syncStatus: 'pending' | 'synced';
}
export interface Expense { id: string; label: string; amount: number; createdAt: string; syncStatus: 'pending' | 'synced'; }
export interface OutboxOperation { id: string; entity: 'sale' | 'product' | 'expense'; entityId: string; operation: 'create' | 'update'; createdAt: string; status: 'pending' | 'synced'; }
export { money, makeId, calculateSaleTotal, calculateCostTotal, validateCatalogItem, validateSale } from './domain-core.mjs';
